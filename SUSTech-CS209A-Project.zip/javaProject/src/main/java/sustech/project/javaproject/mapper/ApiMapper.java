package sustech.project.javaproject.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import sustech.project.javaproject.entity.Api;

@Mapper
public interface ApiMapper extends BaseMapper<Api> {

}
