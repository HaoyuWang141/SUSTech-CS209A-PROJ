package sustech.project.javaproject.crawler_model;

public class JsonAnswer {
    private Integer answer_id;
    private Integer question_id;

    public Integer getAnswer_id() {
        return answer_id;
    }

    public Integer getQuestion_id() {
        return question_id;
    }
}
